# 🌆 CityPulse 360: Multi-City Exploration, Safety & Smart Living Platform

> **Problem Statement:** *City Life: Exploring, Experiencing & Navigating the Chaos We Call Home*  
> CityPulse 360 is an intelligent multi-city geospatial exploration platform that turns urban chaos into verified discovery, culture, and safer mobility across India.

---

## 🇮🇳 Supported Indian Cities (15 Cities)

1. **Pune, Maharashtra** — Shaniwar Wada, Aga Khan Palace, Vaishali on FC Road, Goodluck Cafe, Vetal Tekdi
2. **Mumbai, Maharashtra** — Gateway of India, CSMT, Marine Drive, Bademiya, Yazdani Bakery, Sanjay Gandhi National Park
3. **Nagpur, Maharashtra** — Deekshabhoomi, Sitabuldi Fort, Futala Lake, Keshav Tarri Poha
4. **Nashik, Maharashtra** — Panchavati & Sita Gufa, Sadhana Chulivarchi Misal, Sula Vineyards
5. **Delhi** — Qutub Minar, Humayun's Tomb, Paranthe Wali Gali, Lodhi Gardens
6. **Bengaluru, Karnataka** — Bangalore Palace, Vidyarthi Bhavan, Cubbon Park
7. **Hyderabad, Telangana** — Charminar, Nimrah Cafe & Bakery (Irani Chai), Hussain Sagar Lake
8. **Chennai, Tamil Nadu** — Marina Beach Promenade, Kapaleeshwarar Temple, Murugan Idli Shop
9. **Kolkata, West Bengal** — Victoria Memorial, Peter Cat (Park Street), Princep Ghat
10. **Jaipur, Rajasthan** — Amber Fort, Rawat Mishthan Bhandar (Pyaaz Kachori), Jal Mahal Promenade
11. **Ahmedabad, Gujarat** — Sabarmati Ashram, Manek Chowk Midnight Food Bazaar, Riverfront Promenade
12. **Goa** — Basilica of Bom Jesus, Fontainhas Latin Quarter, Vinayak Fish Thali
13. **Varanasi, Uttar Pradesh** — Kashi Vishwanath Corridor, Dashashwamedh Ghat Aarti, Blue Lassi Shop
14. **Agra, Uttar Pradesh** — The Taj Mahal, Mehtab Bagh, Panchhi Petha
15. **Kochi, Kerala** — Fort Kochi Chinese Fishing Nets, Kashi Art Cafe, Marine Drive Kochi

---

## 🌍 Google Earth & Satellite Integration

The map interface incorporates three views:
1. 🛰️ **Google Satellite (Earth) Mode (Default):** Photorealistic aerial satellite imagery with interactive place pins, safety badges, and route lines.
2. 🗺️ **Street Cartography:** OpenStreetMap high-contrast vector cartography (no API key required).
3. 🌍 **3D Earth Embed & Launch:**
   - Dedicated high-resolution 3D satellite embed viewport.
   - One-click **"Open in Google Earth 3D ↗"** launcher button pointing directly to:
     `https://earth.google.com/web/search/Pune,+Maharashtra/@18.5035801,73.8746239,584.0166196a,35272.37101018d,35y,0h,0t,0r/...`

---

## 🌟 Core Features & Modules

### 1. 🗺️ Exploration & Food
- **8 Functional Filters:** All Places, Street Food & Dining, Hidden Gems, Historical Places, Stays & Hostels, Scenic Promenades, Parks & Gardens, Budget-Friendly ($).
- **Search:** Instant query matching across place names, cities, categories, descriptions, and amenities.
- **Actionable Cards:** Cost for two, crowd level, sample rating, amenities badges, **View Details** modal, and direct **Google Maps Directions**.

### 2. 🏛️ History & Culture Trail
- Architectural styles, centuries-old backstories, visiting etiquette, and entry fees.
- **Narrated Audio Walking Guides:** Live speech synthesis narration with waveform animations for hands-free listening.

### 3. 🛡️ SafeWay Navigator
- **Dual-Path Routing:** Fastest shortcut vs. SafeWay Verified well-lit corridor with CCTV and police booths.
- Hazard blackspot overlays (waterlogging basins, construction bottlenecks).
- **One-Tap SOS Emergency Center:** Direct police, ambulance, and women's helplines with simulated GPS dispatch.
- **Safety Disclaimer:** Explicit notice that all routes are advisory community guidelines.

### 4. ⚖️ Best vs. Worst (Urban Comparison Matrix)
- Side-by-side district benchmark comparator.
- **6-Dimensional Chart.js Radar Chart:** Safety, Cleanliness, AQI, Affordability, Transit Connectivity, and Nightlife/Vibe.

### 5. 📡 Smart City Pulse & Crowdsourced Reporting
- Environmental and traffic choke-point indicators clearly marked with `[Sample Telemetry]`.
- Social media sentiment stream tracking city mood.
- Citizen reporting modal with **Voice Note Speech-to-Text** and community upvoting.

### 6. 🤖 PulseBot AI Concierge
- Local rule-based recommendation engine for city-tailored food, heritage, and safety tips.
- Quick action chips and text-to-speech audio playback.

---

## 🚀 Running the App

```bash
# 1. Start the server
python run.py

# 2. Run automated test suite
python test_app.py
```

- Access application at: **`http://127.0.0.1:8000`**
- Interactive API Swagger: **`http://127.0.0.1:8000/docs`**
